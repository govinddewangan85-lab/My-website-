Star Beauty Parlour & Academy website package.
Owner/Operator: Govind Dewangan.
Trainer: Priti Dewangan.
WhatsApp: +91 77708 86309.
Email: govinddewangan85@gmail.com.
Address: Simga, District Balodabazar, Chhattisgarh.
Includes user-provided photo, course tiles, admission enquiry form that opens WhatsApp, and certificate information.
This website is not published online yet. Keep index.html and govind-priti.jpg together when uploading.
Photos elsewhere on the page load from the internet. No government/PMKVY affiliation is claimed.
